#
# Copyright (C) 2023, Advanced Micro Devices, Inc. All rights reserved.
# SPDX-License-Identifier: MIT
#
from quark.testing.common_utils import slow_test, slow_test_if, skip_if_no_gpu  # type: ignore[unused-ignore, import-not-found]
